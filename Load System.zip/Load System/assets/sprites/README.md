Place .png files in this folder to use them as sprites for your game's actors

Docs: https://www.gbstudio.dev/docs/assets/sprites
